package com.example.seleniumtools.setup;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class cultFit {

	public static void main(String[] args) {
		WebDriver dr=demo.getDriver("chrome");
		dr.get("https://www.cult.fit/fitness");
		dr.manage().window().maximize();
		
		WebElement textdata=dr.findElement(By.xpath("(//div[@data-index='2']//child::div[@class='style-prefix-dvxtzn e1kaeypi1']//child::div[@class='style-prefix-12jkiyh e1ji7sof0'])[2]"));
		System.out.println("Text Mentioned is:"+textdata.getText());
		
	}

}
