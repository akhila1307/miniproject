package com.example.seleniumtools;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DatePickerDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String day="13";
		String month="July";
		String year="2022";
		WebDriverManager.chromedriver().setup();
		WebDriver dr=new ChromeDriver();
		dr.manage().window().maximize();
		dr.get("https://demo.automationtesting.in/Datepicker.html");
		dr.findElement(By.id("datepicker2")).click();
		WebElement m=dr.findElement(By.xpath("//select[@title='Change the month']"));
		Select s= new Select(m);
		s.selectByVisibleText(month);
		WebElement y=dr.findElement(By.xpath("//select[@title='Change the year']"));
		Select s1= new Select(y);
		s1.selectByVisibleText(year);
		dr.findElement(By.linkText(day)).click();

	}

}
