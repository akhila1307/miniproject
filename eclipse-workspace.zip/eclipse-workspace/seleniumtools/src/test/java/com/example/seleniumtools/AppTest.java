package com.example.seleniumtools;

import java.sql.DriverManager;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.example.seleniumtools.pages.LoginPage;
import com.example.seleniumtools.pages.LoginPageFactory;
import com.example.seleniumtools.setup.demo;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class AppTest 
    extends TestCase
{
	public static void main(String args[])
	{
		
		//System.setProperty("Webdriver.chrome.driver", "D:\\driver\\chromedriver.exe");
	//	WebDriver dr=new ChromeDriver();
	//	dr.get("https://www.saucedemo.com");
     	WebDriver dr=demo.getDriver("edge");
		dr.get("https://www.saucedemo.com");
		dr.manage().window().maximize();
//		WebElement username= dr.findElement(By.id("user-name"));
//		WebElement password= dr.findElement(By.id("password"));
//		WebElement button= dr.findElement(By.id("login-button"));
//		username.sendKeys("standard_user");
//		password.sendKeys("secret_sauce");
//		button.click();
		
		
		//POM(page object Model
//		LoginPage lp=new LoginPage(dr);
//		lp.loginUser("standard_user","secret_sauce");
		
		//Page factory model-PageFactory is a predefined class
		LoginPageFactory lpf=PageFactory.initElements(dr,LoginPageFactory.class);
		lpf.loginUser("standard_user","secret_sauce");
		
		WebElement baglink=dr.findElement(By.linkText("Sauce Labs Backpack"));//for hyper link text use linktext
		baglink.click();
		
		WebElement textdata=dr.findElement(By.xpath("//div[@data-test='inventory-item-name']"));
		System.out.println("Text Mentioned is:"+textdata.getText());
		
		//dr.close();
		
		
	}
	
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public AppTest( String testName )
    {
        super( testName );
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( AppTest.class );
    }

    /**
     * Rigourous Test :-)
     */
    public void testApp()
    {
        assertTrue( true );
    }
}
