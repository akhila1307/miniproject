package com.example.seleniumtools;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.example.seleniumtools.setup.demo;

public class AlertDemo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver dr=demo.getDriver("chrome");
		dr.get("https://demo.automationtesting.in/Alerts.html");
		dr.manage().window().maximize();
		
		dr.findElement(By.xpath("//button[@class='btn btn-danger']")).click();
		Thread.sleep(1000);
		Alert a1=dr.switchTo().alert();
		Thread.sleep(1000);
		a1.accept();
		
		dr.findElement(By.linkText("Alert with OK & Cancel")).click();
		dr.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
		Alert a2=dr.switchTo().alert();
		Thread.sleep(1000);
		a2.accept();
		String value=dr.findElement(By.id("demo")).getText();
		System.out.println(value);
		dr.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
		Alert a3=dr.switchTo().alert();
		Thread.sleep(1000);
		a3.dismiss();
		
		dr.findElement(By.linkText("Alert with Textbox")).click();
		dr.findElement(By.xpath("//button[@class='btn btn-info']")).click();
		Alert a4=dr.switchTo().alert();
		a4.sendKeys("Automation Testing Alert Demo");
		Thread.sleep(1000);
		a4.accept();
		String value2=dr.findElement(By.id("demo1")).getText();
		System.out.println(value2);
		String value1=dr.findElement(By.id("demo")).getText();
		System.out.println(value1);
	}

}
