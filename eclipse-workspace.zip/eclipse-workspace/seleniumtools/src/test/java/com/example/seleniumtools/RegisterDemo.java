package com.example.seleniumtools;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.example.seleniumtools.setup.demo;

public class RegisterDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver dr =demo.getDriver("chrome");
		dr.get("https://demo.automationtesting.in/Register.html");
		dr.manage().window().maximize();
		List<WebElement> radio= dr.findElements(By.xpath("//input[@ng-model='radiovalue']"));
		for (WebElement e:radio)
		{
			System.out.println(e.getAttribute("value"));
			if(e.getAttribute("value").equalsIgnoreCase("Male"))
			{
				e.click();
			}
		}
		List<WebElement> checkbox= dr.findElements(By.xpath("//input[@type='checkbox']"));
		for (WebElement e:checkbox)
		{
			System.out.println(e.getAttribute("value"));
			if(e.getAttribute("value").equalsIgnoreCase("Hockey") )
			{
				e.click();
			}
			else if (e.getAttribute("value").equalsIgnoreCase("Cricket") )
			{
				e.click();
			}
		}
		WebElement dropdown =dr.findElement(By.xpath("//select[@id='Skills']"));
		Select sel=new Select(dropdown);
	   //sel.selectByIndex(1);
		sel.selectByValue("Unix");
		WebElement year =dr.findElement(By.xpath("//select[@placeholder=\"Year\"]"));
		Select se=new Select(year);
		se.selectByValue("2002");
		WebElement month =dr.findElement(By.xpath("//select[@placeholder=\"Month\"]"));
		Select mn =new Select(month);
		mn.selectByValue("July");
		WebElement day =dr.findElement(By.xpath("//select[@placeholder=\"Day\"]"));
		Select da=new Select(day);
		da.selectByValue("13");
		

	}

}
