package com.example.seleniumtools;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class WindowDemo {

	public static void main(String[] args) throws AWTException, InterruptedException {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		WebDriver dr=new ChromeDriver();
		dr.manage().window().maximize();
		dr.get("https://demo.automationtesting.in/Windows.html");
		dr.findElement(By.linkText("Open New Tabbed Windows")).click();
		dr.findElement(By.xpath("//button[@class='btn btn-info']")).click();
		String mainWindow=dr.getWindowHandle();
		Set<String> allWindows=dr.getWindowHandles();
		Iterator<String> it =allWindows.iterator();
		while(it.hasNext())
		{
			String childWindow=it.next();
			if(!childWindow.equalsIgnoreCase(mainWindow))
			{
				dr.switchTo().window(childWindow);
				String text=dr.findElement(By.xpath("//h1[@class='d-1 fw-bold']")).getText();
				System.out.println(text);
				System.out.println("Title:"+dr.getTitle());
				dr.close();
				//dr.quit();-close all tabs and browser
				//dr.close();-close only one tab
			}
		}
		dr.switchTo().window(mainWindow);
    JavascriptExecutor js = (JavascriptExecutor) dr;
	js.executeScript("window.scroll(0,80)");//scroll the window
//		js.executeScript("alert(' Javascript Executor demo')");//alert msg
//		//js	.executeScript("documents.getElementsById('analystic').click()" );
//		
		
        Robot r = new Robot();
		r.mouseMove(230,410);
		r.delay(1000);
		r.mousePress(InputEvent.BUTTON1_DOWN_MASK);
		r.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
		Thread.sleep(1000);
		
		
		
		

	}

}
