package com.example.seleniumtools.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {

	WebDriver  dr;
	By username=By.id("user-name");
	By password=By.id("password");
	By loginBtn=By.id("login-button");
	
	public LoginPage(WebDriver dr)
	{
		this.dr=dr;
	}
	public void loginUser(String user,String pass)
	{
		dr.findElement(username).sendKeys(user);
		dr.findElement(password).sendKeys(pass);
		dr.findElement(loginBtn).click();
	}
}
