package com.example.seleniumtools.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPageFactory {
	@FindBy(id="user-name")
	WebElement username;
	@FindBy(id="password")
	WebElement password;
	@FindBy(id="login-button")
	WebElement loginBtn;
	WebDriver dr;
	public LoginPageFactory(WebDriver dr)
	{
		this.dr=dr;
	}
	public void loginUser(String user,String pass)
	{
		username.sendKeys(user);
		password.sendKeys(pass);
		loginBtn.click();
	}
	
	

}
