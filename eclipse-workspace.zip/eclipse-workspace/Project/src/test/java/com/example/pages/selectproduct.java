package com.example.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class selectproduct {
	WebDriver dr;
	@FindBy(linkText="Push It Messenger Bag")
	WebElement select;
	@FindBy(xpath="//span[@class='base']")
	WebElement valid;
	public selectproduct(WebDriver dr)
	{
		this.dr=dr;
	}
	public  void performselect()
	{
		select.click();
	}

	public String getLogoTitle()
	{
		String s=valid.getText();
		return s;
	}

}
