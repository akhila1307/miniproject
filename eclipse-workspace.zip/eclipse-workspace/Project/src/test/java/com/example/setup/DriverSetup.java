package com.example.setup;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DriverSetup {
 WebDriver  dr;
	public WebDriver getDriver(String browser,String url)
	{
		if(browser.equalsIgnoreCase("chrome"))
		{
			WebDriverManager.chromedriver().setup();
			dr=new ChromeDriver();
			dr.manage().window().maximize();	
			dr.get(url);
			return dr;
			
		}
		else if(browser.equalsIgnoreCase("edge"))
		{
			WebDriverManager.edgedriver().setup();
			dr=new EdgeDriver();
			dr.manage().window().maximize();	
			dr.get(url);
			return dr;
		}
		else if(browser.equalsIgnoreCase("firefox"))
		{
			WebDriverManager.firefoxdriver().setup();
			dr=new FirefoxDriver();
			dr.manage().window().maximize();	
			dr.get(url);
			return dr;
		}
		return null;

     }
		public void closeDriver()
		{
			dr.close();
				
		}
			
}