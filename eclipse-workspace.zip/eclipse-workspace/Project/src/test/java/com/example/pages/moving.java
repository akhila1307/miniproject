package com.example.pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class moving {
	WebDriver dr;
	@FindBy(xpath="//span[@class='base']")
	WebElement  title;
	public moving(WebDriver dr)
	{
		this.dr=dr;
	}
	public  void cursor() throws AWTException, InterruptedException {
		 Robot r = new Robot();
			r.mouseMove(430,330);
			r.delay(1000);
			r.mouseMove(430,400);
			r.mousePress(InputEvent.BUTTON1_DOWN_MASK);
			r.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
			Thread.sleep(1000);
	}
	public String getLogoTitle()
	{
		String s=title.getText();
		return s;
	}
	
}
