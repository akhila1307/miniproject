package com.example.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Addtocart {
	WebDriver dr;
	@FindBy(id="product-addtocart-button")
	WebElement cart;
	@FindBy(xpath="//a[@class='action showcart']")
	WebElement finding;
	@FindBy(xpath="//a[@data-bind='attr: {href: product_url}, html: product_name']")
	WebElement title;
	
	public Addtocart(WebDriver dr)
	{
		this.dr=dr;
	}
	public  void performcart() throws InterruptedException 
	{
		cart.click();
		finding.click();
		
	}
	public String getLogoTitle()
	{
		String s=title.getText();
		return s;
	}


	


}
