package com.example;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.example.pages.Addtocart;
import com.example.pages.LoginPage;
import com.example.pages.checkoutpage;
import com.example.pages.moving;
import com.example.pages.selectproduct;
import com.example.setup.DriverSetup;
import com.example.utils.ExtentReportGenerator;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;


public class AppTest 
{
	WebDriver dr;
	DriverSetup initDriver;
	LoginPage loginpage;
	moving movingpage;
	selectproduct productpage;
	Addtocart cartpage;
	checkoutpage checkout;
	
	ExtentReportGenerator reportgen;
	ExtentReports reports;
	ExtentTest test;
	@BeforeTest
	public void setUp()
	{
		initDriver=new DriverSetup();
		dr= initDriver.getDriver("chrome","https://magento.softwaretestingboard.com");
		loginpage=PageFactory.initElements(dr, LoginPage.class);
		movingpage=PageFactory.initElements(dr, moving.class);
		productpage=PageFactory.initElements(dr, selectproduct.class);
		cartpage=PageFactory.initElements(dr, Addtocart.class);
		checkout=PageFactory.initElements(dr, checkoutpage.class);
	
		reports =new ExtentReports("Automation Testing ");
		reportgen= new ExtentReportGenerator(dr,reports);
	}
	@Test
	public void testLoginFunction() throws IOException 
	{
		loginpage.performLogin("akulaaakhila13@gmail.com","Akhila@13");
		String act=loginpage.getLogoTitle();
		Assert.assertEquals(act, "Welcome, AKULA Akhila!");
		reportgen.generateReport("Login Test Case",act,"Welcome, AKULA Akhila!","Login Success","Login Failure");
	  
    }
	@Test
	public void testmoving() throws AWTException, InterruptedException, IOException
	{
		movingpage.cursor();
		String act=movingpage.getLogoTitle();
		Assert.assertEquals(act, "Bags");
		reportgen.generateReport("Moving",act,"Bags","moving correct page","Moving wrong page");
		
	}
	@Test
	public void testproduct() throws IOException 
	{
		productpage.performselect();
		String act=movingpage.getLogoTitle();
		Assert.assertEquals(act, "Push It Messenger Bag");
		reportgen.generateReport("selecting the product ",act,"Push It Messenger Bag","validproduct","invalidproduct");
	}
	@Test
	public void testwait() throws InterruptedException, IOException  
	{
		cartpage.performcart();
     	String act=cartpage.getLogoTitle();
		Assert.assertEquals(act, "Push It Messenger Bag");
		reportgen.generateReport("validating the product  ",act,"Push It Messenger Bag","add success","add fail");
	}
	@Test 
	public void testycart() throws InterruptedException, IOException {
		checkout.proceeds("sattenapalli","guntur","Alabama","12345-6789","9823516784");
		String act=checkout.getLogoTitle();
		System.out.println(act);
		Assert.assertEquals(act, "Order Summary");
		reportgen.generateReport("placing the order ",act,"Order Summary","checkout success","checkout fail");
		
		
	}
	
//	@AfterClass
//	public void tearDown()
//	{
//		initDriver.closeDriver();
//		
//	}
}
