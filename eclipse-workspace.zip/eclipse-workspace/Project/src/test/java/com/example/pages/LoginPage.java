package com.example.pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage {


	
	    @FindBy(linkText="Sign In")
	    WebElement signin;
		@FindBy(id="email")
		WebElement username;
		@FindBy(id="pass")
		WebElement password;
		@FindBy(xpath="//div[@class='primary']//child::button[@class='action login primary']")
		WebElement loginBtn;
		@FindBy(xpath="//span[@class='logged-in'][1]")
		WebElement title;
		WebDriver dr;
		
		public LoginPage(WebDriver dr)
		{
			this.dr=dr;
		}
		public void performLogin(String user,String pass)
		{  
			signin.click();
			username.sendKeys(user);
			password.sendKeys(pass);
			loginBtn.click();
		}
		public String getLogoTitle()
		{
			WebDriverWait wait=new WebDriverWait(dr,Duration.ofSeconds(1000));
			wait.until(ExpectedConditions.visibilityOf(title));
			String s=title.getText();
			return s;
		}
	

	}


