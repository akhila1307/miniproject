package com.example.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class checkoutpage {
	WebDriver dr;
	@FindBy(id="top-cart-btn-checkout")
	WebElement proceed;
//	@FindBy(xpath="//fieldset[@class='field street admin__control-fields required']//child::div//child::div[@name='shippingAddress.street.0']")
	@FindBy(xpath="//input[@type='text' and @aria-required='true' and @name='street[0]']")
	WebElement username;
	@FindBy(xpath="//input[@type='text' and @aria-required='true' and @name='city']")
    WebElement town;
	@FindBy(xpath="//select[ @name='region_id']")
	WebElement state;
	@FindBy(xpath="//input[@type='text' and @aria-required='true' and @name='postcode']")
	WebElement pincode;
	@FindBy(xpath="//input[@type='text' and @aria-required='true' and @name='postcode']")
	WebElement pin;
	@FindBy(xpath="//input[@type='text' and @aria-required='true' and @name='telephone']")
    WebElement mobile;
	@FindBy(xpath="//td[@class='col col-price']//child::span[@class='price']")
	WebElement radio;
	@FindBy(xpath="//div[@class='primary']//child::button[@data-role='opc-continue']")
	WebElement finish;
	@FindBy(xpath="//span[@class='title']")
	WebElement valid;
	
	public checkoutpage(WebDriver dr)
	{
		this.dr=dr;
	}
	public void proceeds( String user , String city,String country,String pincode,String phonenumber) throws InterruptedException 
	{   
		
		proceed.click();
		Thread.sleep(5000);
        username.sendKeys(user);
        town.sendKeys(city);
        Select s= new Select(state);
		s.selectByVisibleText(country);
		pin.sendKeys(pincode);
		mobile.sendKeys(phonenumber);
		radio.click();
		finish.click();
        
	}
	public String getLogoTitle()
	{
		String s=valid.getText();
		return s;
	}

}
