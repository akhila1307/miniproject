package comm.example;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class log {
	
	@Test(priority=1,description="this is 1st test")
	public void blogin()
	{
		System.out.println("before");
	}
	@Test(priority=2,description="this is 2nd test")
	public void alogout()
	{
		System.out.println("After");
	}
	
	@BeforeTest
	public void DBTestlogin()
	{
		System.out.println("Connection Done");
	}
	@AfterTest
	public void DBTestlost()
	{
		System.out.println("Connection close");
	}
	@BeforeMethod
	public void TestM()
	{
		System.out.println("Before each Method");
	}
	@AfterMethod
	public void TestMA()
	{
		System.out.println("After each method");
	}
	
	
}
