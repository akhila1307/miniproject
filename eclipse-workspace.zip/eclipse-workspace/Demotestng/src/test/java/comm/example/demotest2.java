package comm.example;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;


public class demotest2 {
	@Test
	public void testtitle()
	{
		SoftAssert sa =new SoftAssert();
		String expText="Search";
		WebDriver dr=new ChromeDriver();
		dr.get("Https://www.ebay.com");
		System.out.println(dr.getTitle());
		System.out.println("verifying Title");
		String exptitle="Electronics, Cars, Fashion, Collectibles &amp; More | eBay";
		String acttitle=dr.getTitle();
		sa.assertEquals(acttitle,exptitle);
		System.out.println("verifying text");
		String actText=dr.findElement(By.xpath("//*[@id=\"gh-btn\"]")).getAttribute("value");
		sa.assertEquals(actText, expText,"comparing text.....");
		sa.assertAll();
		
		
	}

}
