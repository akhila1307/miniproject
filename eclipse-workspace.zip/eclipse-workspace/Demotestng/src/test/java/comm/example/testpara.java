package comm.example;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;
import org.testng.annotations.Parameters;
import org.openqa.selenium.chrome.ChromeDriver;

public class testpara {
	public WebDriver dr;
	@Parameters({"browser"})
	@Test
public void test3(String browser) {
		if(browser.equals("Chrome")) {
			dr=new ChromeDriver();
		}
		else if(browser.equals("Firefox")) {
			dr=new FirefoxDriver();
		}
		else if(browser.equals("Edge")) {
			dr=new EdgeDriver();
	}
		dr.get("http://www.google.com");
		dr.manage().window().maximize();
}
}