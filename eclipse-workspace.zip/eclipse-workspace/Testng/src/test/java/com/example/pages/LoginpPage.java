package com.example.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginpPage {
	@FindBy(id="user-name")
	WebElement username;
	@FindBy(id="password")
	WebElement password;
	@FindBy(id="login-button")
	WebElement loginBtn;
	@FindBy(xpath="//div[@class='app_logo']")
	WebElement appTitle;
	WebDriver dr;
	
	public LoginpPage(WebDriver dr)
	{
		this.dr=dr;
	}
	public void performLogin(String user,String pass)
	{
		username.sendKeys(user);
		password.sendKeys(pass);
		loginBtn.click();
	}
	public String getLogoTitle()
	{
		String s=appTitle.getText();
		return s;
	}

}
