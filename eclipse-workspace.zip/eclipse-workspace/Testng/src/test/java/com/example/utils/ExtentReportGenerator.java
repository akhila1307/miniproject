package com.example.utils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class ExtentReportGenerator {
	ExtentReports report;
	WebDriver dr;
	public ExtentReportGenerator (WebDriver dr,ExtentReports report)
	{
		this.dr=dr;
		this.report=report;
	}
	
	public void generateReport(String tcname,String actual,String expected,String passValue,String failValue) throws IOException
	{
		ExtentTest test=report.startTest(tcname);
		if (actual.equals(expected))
		{
			test.log(LogStatus.PASS, passValue);
			File screenshot =((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshot, new File("C:\\Users\\akula\\eclipse-workspace\\Testng\\screenshot\\"+passValue+".png"));
		}
		else
		{
			test.log(LogStatus.FAIL, failValue);
			File screenshot =((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshot, new File("C:\\Users\\akula\\eclipse-workspace\\Testng\\screenshot\\"+failValue+".png"));
		}
		report.endTest(test);
	}

}
