package com.example;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.example.pages.LoginpPage;
import com.example.pages.ProductPage;
import com.example.setup.DriverSetup;
import com.example.utils.ExtentReportGenerator;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class AppTest 
{
	WebDriver dr;
	DriverSetup initDriver;
	LoginpPage loginpage;
	ProductPage productPage;
	
	ExtentReports reports;
	ExtentTest test;
	ExtentReportGenerator reportgen;
	@BeforeClass
	public void setUp()
	{
		initDriver=new DriverSetup();
		dr= initDriver.getDriver("chrome","https://www.saucedemo.com/");
		loginpage=PageFactory.initElements(dr, LoginpPage.class);
		productPage=PageFactory.initElements(dr, ProductPage.class);
		
		reports =new ExtentReports("Automation Testing ");
		reportgen= new ExtentReportGenerator(dr,reports);
	}
	@Test
	public void testLoginFunction() throws IOException
	{
		loginpage.performLogin("standard_user","secret_sauce");
		String act=loginpage.getLogoTitle();
		Assert.assertEquals(act, "Swag Labs");
		reportgen.generateReport("Login Test Case",act,"Swag Labs","Login Success","Login Failure");
		
		
	}
	@Test
	public void testProductDetails() throws IOException
	{
		productPage.clickBikeLight();
		String actual=productPage.getProductName();
		Assert.assertEquals(actual, "Sauce Labs Bike Light");
		
		
		reportgen.generateReport("product Test Case",actual,"Sauce Labs Bike Light","Valid Product","Invalid Product");
	}
	@AfterClass
	public void tearDown()
	{
		initDriver.closeDriver();
		reports.endTest(test);
		reports.flush();
	}
	
	
}
