package com.example.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ProductPage {
	@FindBy(linkText="Sauce Labs Backpack")
	WebElement backpack;
	@FindBy(linkText="Sauce Labs Bike Light")
	WebElement bikeLight;
	@FindBy(xpath="//div[@data-test='inventory-item-name']")
	WebElement productName;
	WebDriver dr;
	public ProductPage(WebDriver dr)
	{
		this.dr=dr;
	}
	public void clickBackPack()
	{
		backpack.click();
	}
	public void clickBikeLight()
	{
		bikeLight.click();
	}
	public String  getProductName()
	{
		return productName.getText();
	}

}
