package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class amazons {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ChromeDriver ch=new ChromeDriver();
		ch.get("https://www.google.com");
		ch.manage().window().maximize();
		ch.findElement(By.xpath("//*[@id=\"APjFqb\"]")).sendKeys("amazon");
		ch.findElement(By.xpath("/html/body/div[1]/div[3]/form/div[1]/div[1]/div[4]/center/input[1]")).click();
		ch.findElement(By.xpath("//*[@id=\"tads\"]/div/div/div/div/div[1]/a/div[1]/span")).click();
		ch.findElement(By.xpath("//*[@id=\"nav-link-accountList-nav-line-1\"]")).click();
		ch.findElement(By.xpath("//*[@id=\"ap_email\"]")).sendKeys("8106611096");
		ch.findElement(By.xpath("//*[@id=\"continue\"]")).click();
		ch.findElement(By.xpath("//[@id=\"ap_password\"]")).sendKeys("Akhila@1307");
		ch.findElement(By.xpath("//*[@id=\"signInSubmit\"]")).click();
		ch.findElement(By.xpath("//*[@id=\"nav-recently-viewed\"]/span[1]")).click();
		ch.findElement(By.xpath("//*[@id=\"p13n-asin-index-0\"]/div/a/div/img")).click();
		ch.findElement(By.xpath("//*[@id=\"add-to-cart-button\"]")).click();
		ch.findElement(By.xpath("//*[@id=\"sc-buy-box-ptc-button\"]/span/input")).click();
		ch.findElement(By.xpath("//*[@id=\"shipToThisAddressButton\"]/span/input")).click();
		ch.findElement(By.xpath("//*[@id=\"pp-GItZQi-137\"]/div/div/div/div/div[2]/div[1]/div/span[1]")).click();
	}

}
