package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class demo1 {
    public static String browser="chrome";
    public static WebDriver dr;
  
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		if (browser.equals("chrome")) {
			dr=new ChromeDriver();
		}else if(browser.equals("firefox")) {
			dr=new FirefoxDriver();
			
		}else if(browser.equals("Edge")) {
			dr=new EdgeDriver();
		}
        dr.get("http://localhost:8081");
        dr.manage().window().maximize();
        dr.findElement(By.id("APjFqb")).sendKeys("mobile");
	}

}
