package selenium;

import org.openqa.selenium.By;
//import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;

public class demo {

	public static void main(String[] args) {
	    ChromeDriver ch=new ChromeDriver() ;
		
		//InternetExplorarDriver ch=new InternetExplorarDriver();
		//ch.get("https://magento.softwaretestingboard.com/women.html");
		//ch.manage().window().maximize();
		//ch.findElement(By.xpath("//*[@id=\"APjFqb\"]")).sendKeys("flipkart");
		//ch.findElement(By.xpath("/html/body/div[1]/div[3]/form/div[1]/div[1]/div[4]/center/input[1]")).click();
		//ch.findElement(By.xpath("//*[@id=\"rso\"]/div[1]/div/div/div/table/tbody/tr[2]/td/div/div/div/div/h3/a")).click();
		//ch.switchTo().newWindow(WindowType.TAB);
		
		//String url = "https://demoqa.com";
		//ch.get(url);
		/*String title =ch.getTitle();
		int titlelength =ch.getTitle().length();
		System.out.println("Title of thr page is:"+title);
		System.out.println("Lemgth of  teh title is:"+titlelength);
		String actualurl=ch.getCurrentUrl();
		if (actualurl.equals(url)) {
			System.out.println("Verification Successful-The Correcet url is opened");
		}
		else {
			System.out.println("Verification Failed -An incorrect url is opened");
			System.out.println("Actual URL is:"+actualurl);
			System.out.println("Expected URL is:"+url);
		}*/
		//ch.manage().window().maximize();
		//ch.findElement(By.xpath("//*[@id=\"app\"]/div/div/div[1]/a/img")).click();
		/*String urls = "https://www.toolsqa.com/selenium-training/";
		ch.get(urls);
		ch.findElement(By.xpath("/html/body/div[1]/div[1]/div/div[1]/div[2]/a")).click();
		ch.navigate().back();
        }
*/
}
}
