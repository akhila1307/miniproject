package com.example.Steps;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import junit.framework.Assert;

public class LoginStepDefinition {
	WebDriver dr;
	@Given("User is on login page")
	public void user_is_on_login_page()
	{
		WebDriverManager.chromedriver().setup();
		dr=new ChromeDriver();
		dr.manage().window().maximize();
		dr.get("https://saucedemo.com/");
	}
	@When("user enter valid {string} and {string}")
	public void user_enter_valid_and(String username,String password)
	{
		dr.findElement(By.id("user-name")).sendKeys(username);
		dr.findElement(By.id("password")).sendKeys(password);
		
	}
	@When("user enter valid username and password")
	public void user_enter_valid_username_and_password()
	{
		dr.findElement(By.id("user-name")).sendKeys("standard_user");
		dr.findElement(By.id("password")).sendKeys("secret_sauce");
		
	}
	@And("clicks on login button")
	public void clicks_on_login_button()

	{
		dr.findElement(By.id("login-button")).click();
	}
	@Then("User is logged in and navigate to product page")
	public void user_is_logged_in_and_navigate_to_product_page()
	{
		String name=dr.findElement(By.xpath("//div[@class='app_logo']")).getText();
		Assert.assertEquals("Swag Labs", name);
	}
}












	/*@When("user enters valid username")
	public void user_enters_valid_username()
	{
		dr.findElement(By.id("user-name")).sendKeys("standard_user");
		
	}
	@But ("enter invalid password")
	public void enter_inavlid_password()
	{
		dr.findElement(By.id("password")).sendKeys("secret_sauces");	
	}
	@Then ("User gets a message on invalid password")
	public void user_gets_a_message_on_invalid_password()
	{
		String name = dr.findElement(By.xpath("//h3[@data-test='error']")).getText();
		Assert.assertEquals("Epic sadface: Username and password do not match any user in this service", name);
	}*/
	
	
	
	
	


