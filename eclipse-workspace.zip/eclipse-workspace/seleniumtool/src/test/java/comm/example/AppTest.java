package comm.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


 
public class AppTest 
{
	public static void main(String args[])
	{
		
		System.setProperty("Webdriver.chrome.driver", "D:\\driver\\chromedriver.exe");
		WebDriver dr=new ChromeDriver();
		dr.manage().window().maximize();
		dr.get("https://www.saucedemo.com");
		WebElement username= dr.findElement(By.id("user-name"));
		WebElement password= dr.findElement(By.id("password"));
		WebElement button= dr.findElement(By.id("login-button"));
		username.sendKeys("standard_user");
		password.sendKeys("secret_sauce");
		button.click();
		
	}
   
}
